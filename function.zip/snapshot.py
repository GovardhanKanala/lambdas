import boto3
from datetime import datetime, timezone, timedelta
from tabulate import tabulate

def lambda_handler(event, context):
    # Initialize EC2 client
    ec2_client = boto3.client('ec2')

    # Calculate the time threshold for 1 week ago
    one_week_ago = datetime.now(timezone.utc) - timedelta(weeks=1)

    # Describe snapshots owned by the AWS account
    snapshots = ec2_client.describe_snapshots(OwnerIds=['self'])  # 'self' refers to the current AWS account

    old_snapshots = []

    # Loop through snapshots and find those older than one week
    for snapshot in snapshots['Snapshots']:
        # Get the snapshot's creation date
        creation_date = snapshot['StartTime']

        # Check if the snapshot is older than one week
        if creation_date < one_week_ago:
            # Get the snapshot's ID, size, and name (if it has a tag named 'Name')
            snapshot_id = snapshot['SnapshotId']
            size = snapshot['VolumeSize']
            name = 'Unnamed'

            # Get snapshot name from tags
            if 'Tags' in snapshot:
                for tag in snapshot['Tags']:
                    if tag['Key'] == 'Name':
                        name = tag['Value']
                        break

            # Add the snapshot details to the old_snapshots list
            old_snapshots.append([snapshot_id, name, creation_date.strftime('%Y-%m-%d %H:%M:%S'), size])

    # Print the details of snapshots older than 1 week in a table format
    if old_snapshots:
        headers = ['Snapshot ID', 'Name', 'Creation Date', 'Size (GiB)']
        table = tabulate(old_snapshots, headers, tablefmt='grid')
        print(table)
    else:
        print("No snapshots older than one week found.")

    return {
        'statusCode': 200,
        'body': old_snapshots
    }
